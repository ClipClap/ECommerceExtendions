=== ClipClap Payment Gateway for WooCommerce ===
Contributors: deusnoname, digitalhydra
Tags: WooCommerce, Payment Gateway, Clipclap, Pagos en linea Colombia, Pagos en linea Latinoamerica
Requires at least: 3.7
Tested up to: 4.4
Stable tag: 1.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

ClipClap Payment Gateway for WooCommerce. Recibe pagos por internet en latinoaméica usando la App Billetera ClipClap.

== Description ==

Si tienes una tienda implementada en [WordPress](https://www.wordpress.org) y [Woocommerce](https://wordpress.org/plugins/woocommerce/)  puedes usar este plugin para aceptar pagos atraves de la App Billetera ClipClap

Guia de Instalación:
---

* Asegurese de tener Wocommerce actualizado y activo antes de seguir con los siguientes pasos.
* Descomprima y Suba el contenido del plugin a `/wp-content/plugins/` .
* En el administrador de wordpress en la seccion de plugins active el plugin **WooCommerce - ClipClap Gateway**.

Configuración
---
* Valla a la seccion de ajustes de **WooCommerce**, y de click en la pestaña Finalizar compra.
* Seleccione **ClipClap** para editar las opciones. Si la opcione **ClipClap** no aparece verifique que se haya activado el plugin primero.
* Seleccione la opcion Activar pagos por ClipClap.
* Configure las opciones necesarias como los datos de su cuenta y el nombre del metodo de pago.
* Guarde los cambios.

== Screenshots ==



== Frequently Asked Questions ==

= What is the cost for transaction for ClipClap? =

It may vary on each country, check clipclap.com to learn more.

= Issues =

== Changelog ==

= 1.0 =
* First Public Release.


== Upgrade Notice ==
