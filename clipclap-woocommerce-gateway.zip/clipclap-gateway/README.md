﻿Plugin Billetera ClipClap para Woocommerce 
================

Si tienes una tienda implementada en [WordPress](https://www.wordpress.org) y [Woocommerce](https://wordpress.org/plugins/woocommerce/)  puedes usar este plugin para aceptar pagos atraves de la App Billetera ClipClap

Guia de Instalación:
---

* Asegurese de tener Wocommerce actualizado y activo antes de seguir con los siguientes pasos.
* Descomprima y Suba el contenido del plugin a `/wp-content/plugins/` .
* En el administrador de wordpress en la seccion de plugins active el plugin **WooCommerce - ClipClap Gateway**.

Configuración
---
* Valla a la seccion de ajustes de **WooCommerce**, y de click en la pestaña Finalizar compra.
* Seleccione **ClipClap** para editar las opciones. Si la opcione **ClipClap** no aparece verifique que se haya activado el plugin primero.
* Seleccione la opcion Activar pagos por ClipClap.
* Configure las opciones necesarias como los datos de su cuenta y el nombre del metodo de pago.
* Guarde los cambios.
