﻿#(For ClipClap)
------

#ClipClap Extention for Opencart 2.0.x
======

Module Name: ClipClap Extention for Opencart 2.0.x
Module URI: http://clipclap.com.co/
Description: ClipClap Billetera for Opencart 2.0.x. Recibe pagos en atraves de la billetera ClipClap
Version: 1.0.0
Author: Code is Everywhere - Jairo Ivan Rondon Mejia
Author URI: http://www.codeiseverywhere.com/
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

========================
# English manual 
---------

ClipClap Extention for CMS Opencart ( Live update version )

( Checked on version 2.0.х )

Installation

1. Copy folders 'admin' and 'catalog' to main folder of your site
2. Enter to admin panel
- Choose  "Extentions" -> "Payment"
3. Find a method "ClipClap" 
- Push the button  "Install" 
- Push the button "Change"
- Enter your personal settings
Exemple of settings will be on screenshot

![Screenshot][1]


[1]: http://clipclap/images/screenshot-opencart.jpg

