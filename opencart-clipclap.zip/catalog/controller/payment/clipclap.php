<?php
class ControllerPaymentClipClap extends Controller {
	public function index() { 
		$this->language->load('payment/clipclap');
		
		$data['text_test'] = $this->language->get('text_testmode');
		$data['button_confirm'] = $this->language->get('button_confirm');

		$this->load->model('checkout/order');

		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
		
		if ($order_info) {
			
			$data['apikey'] = $this->config->get('clipclap_apikey');
			$data['iva_type'] = $this->config->get('clipclap_iva_type');
			$data['button_theme'] = $this->config->get('clipclap_button_theme');
			$data['debug'] = $this->config->get('clipclap_debug');
			$data['order_id'] = $this->session->data['order_id'];
			$data['item_name'] = html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8');
			
			$data['products'] = array();
			$data['redirect_callback'] = $this->url->link('payment/clipclap/callback');
			
			foreach ($this->cart->getProducts() as $product) {
				$option_data = array();
	
				foreach ($product['option'] as $option) {
					if ($option['type'] != 'file') {
						$value = $option['option_value'];	
					} else {
						$filename = $this->encryption->decrypt($option['option_value']);
						
						$value = utf8_substr($filename, 0, utf8_strrpos($filename, '.'));
					}
										
					$option_data[] = array(
						'name'  => $option['name'],
						'value' => (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value)
					);
				}
				
				$data['products'][] = array(
					'name'     => $product['name'],
					'model'    => $product['model'],
					'price'    => $this->currency->format($product['price'], $order_info['currency_code'], false, false),
					'quantity' => $product['quantity'],
					'option'   => $option_data,
					'weight'   => $product['weight']
				);
			}

			$data['discount'] = 0;
			
			$total = $this->currency->format($order_info['total'] , $order_info['currency_code'], $order_info['currency_value'], false);
			
			$data['netValue'] = $total;
			$data['taxValue'] = ($total*$this->config->get('clipclap_iva_type'))/100;

				$data['payerFullName'] = html_entity_decode($order_info['payment_firstname'].' '.$order_info['payment_lastname'], ENT_QUOTES, 'UTF-8');	
				$data['buyerEmail'] = $order_info['email'];
				
				$data['paymentRef'] = 'Order_'.$this->session->data['order_id'].':'.strtotime($order_info['date_added']);
				
				$data['description'] = $this->config->get('config_name').' - '.$this->session->data['order_id'] . ' - ' . html_entity_decode($order_info['payment_firstname'], ENT_QUOTES, 'UTF-8') . ' ' . html_entity_decode($order_info['payment_lastname'], ENT_QUOTES, 'UTF-8');
				
				
			if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/payment/clipclap.tpl')) {
				return $this->load->view($this->config->get('config_template') . '/template/payment/clipclap.tpl', $data);
			} else {
				return $this->load->view('default/template/payment/clipclap.tpl', $data);
			}
		}
	}
	
	public function callback() {
		$order_status_id='';
		$goTo=$this->url->link('checkout/checkout');
		
		//process inicial payment callback
		if (isset($this->request->post['order_id'])) {
			if (isset($this->request->post['order_id'])) {
				$order_id = $this->request->post['order_id'];
			} else {
				$order_id = 0;
			}		
			$this->load->model('checkout/order');
					
		
			$order_info = $this->model_checkout_order->getOrder($order_id);

			$estado = $this->request->post['estado'];
			$codRespuesta = $this->request->post['codRespuesta'];
			$paymentRef = $this->request->post['paymentRef'];
			$token = $this->request->post['token'];
			$numAprobacion = $this->request->post['numAprobacion'];
			$fechaTransaccion = $this->request->post['fechaTransaccion'];

			if ($order_info) {
				if(isset($this->request->post['codRespuesta'])){
					$order_status_id = $this->config->get('clipclap_order_status_pending');
					switch ( $codRespuesta ) {
			            case '3001' :
							$order_status_id = $this->config->get('clipclap_order_status_accepted');
							$this->log->write('ClipClap :: Transaction data OK! '.$estado);
							$this->log->write('ClipClap :: orden token: '.$token);
							$this->log->write('ClipClap :: orden codRespuesta: '.$codRespuesta);
							$this->log->write('ClipClap :: orden paymentRef: '.$paymentRef);
							$this->log->write('ClipClap :: orden numAprobacion: '.$numAprobacion);
							$this->log->write('ClipClap :: orden fechaTransaccion: '.$fechaTransaccion);

							$goTo=$this->url->link('checkout/success');	
						break;
			            case '1000' :	
			            case '1002' :
							$order_status_id = $this->config->get('clipclap_order_status_failed');
							$this->log->write('ClipClap :: Transaction data OK! '.$estado.' ' . ($paymentRef));
									$goTo=$this->url->link('checkout/checkout');	
			            	break;
			            default :
							$order_status_id = $this->config->get('clipclap_order_status_failed');
							$goTo=$this->url->link('checkout/checkout');	
							$this->log->write('ClipClap :: Default state! ' . ($paymentRef));
			            break;
				    }

					if (!$order_info['order_status_id']) {
						$this->model_checkout_order->addOrderHistory($order_id, $order_status_id);
					} else {
						$this->model_checkout_order->addOrderHistory($order_id, $order_status_id);
					}

				} else {
					$this->model_checkout_order->addOrderHistory($order_id, $this->config->get('clipclap_order_status_failed'));
				}
				
			}
			// echo $goTo;
			$this->response->redirect($goTo);
		}
	}
}

