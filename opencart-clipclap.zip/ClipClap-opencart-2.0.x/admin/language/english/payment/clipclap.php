<?php
// Heading
$_['heading_title']      = 'ClipClap';

// Text 
$_['text_payment']       = 'Payment';
$_['text_clipclap']	= '<a onclick="window.open(\'http://www.clipclap.com/billetera\');"><img width="120" src="view/image/payment/clipclap-billetera.png" alt="ClipClap" title="PayU" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_success']       = 'Configuracion Actualizada';
$_['text_pay']           = 'ClipClap';
$_['text_card']          = 'Habilitar pagos con billetera ClipClap';
$_['tab_status']          = 'Configuracion de estados';
$_['tab_general']          = 'Configuracion General';

// Entry
$_['entry_apikey']		= 'API Key:';
$_['entry_button_theme']   = 'Tema del boton:';
$_['entry_iva_type']    = 'Tipo de Iva:';
$_['entry_debug']        = 'Activar Debug:';
$_['entry_debug_on']     = 'Si';
$_['entry_debug_off']    = 'No';

$_['entry_order_status_accepted'] = 'Order status after payment accepted:';
$_['entry_order_status_pending'] = 'Order status after when payment is pending:';
$_['entry_order_status_declined'] = 'Order status after payment is declined:';
$_['entry_order_status_canceled'] = 'Order status after payment is canceled:';
$_['entry_order_status_failed'] = 'Order status after payment is failed:';
$_['entry_order_status_expired'] = 'Order status after payment is expired:';

$_['entry_status']       = 'Estado:';
$_['entry_sort_order']   = 'Orden:';

// Error
$_['error_permission']   = "You haven't permission !";
$_['error_button_theme']   = 'Debe especificar el tema del boton';
$_['error_apikey']    	 = 'API key esta vacia!';
$_['error_iva_type']    = 'Debe especificar el iva!';
?>