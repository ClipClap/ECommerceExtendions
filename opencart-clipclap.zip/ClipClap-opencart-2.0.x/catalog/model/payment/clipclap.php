<?php 
class ModelPaymentClipClap extends Model {
  	public function getMethod($address, $total) {
		$this->load->language('payment/clipclap');
		
		$currencies = array(
			 'COP'
		);
		
		if (!in_array(strtoupper($this->currency->getCode()), $currencies)) {
			$status = false;
		}else{
			$status = true;
		}		
		$method_data = array();
	
		//if ($status) {
      		$method_data = array(
        		'code'       => 'clipclap',
        		'title'      => $this->language->get('text_title'),
				'terms'      => '',
				'sort_order' => $this->config->get('clipclap_sort_order')
			);
    	//}

    	return $method_data;
  	}
}
?>