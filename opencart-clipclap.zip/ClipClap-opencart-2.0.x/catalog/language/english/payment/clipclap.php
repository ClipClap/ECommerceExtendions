<?php
// Text
$_['text_title'] = 'Pagar con la Billetera ClipClap';
$_['text_testmode']	= 'Warning: The payment gateway is in \'Test Mode\'. Your account will not be charged.';
$_['text_total']	= 'Shipping, Handling, Discounts & Taxes';
?>