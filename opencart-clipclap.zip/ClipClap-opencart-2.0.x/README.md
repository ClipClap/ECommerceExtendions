﻿Extención Billetera ClipClap para Opencart 2.0.x
================

Si tienes una tienda implementada en [Opencart](http://www.opencart.com/) puedes usar esta extención para aceptar pagos atraves de la App Billetera ClipClap

Guia de Instalación:
---


- Copiar las carpetas 'admin' and 'catalog' en la raiz de su instalacion de Opencart
- Entrar al panel de administracion de Opencart > Escoger  "Extentions" -> "Payment"
- Busque el metodo "ClipClap" 
- Dar click en  "Install" 
- Dar click en "Change"
- Ingrese los datos de su cuenta ClipClap y las configuraciones que desee
- Seleccione Activar en el menu Estado

**Información**

- Module Name: ClipClap Extention para Opencart 2.0.x
- Module URI: http://clipclap.com.co/
- Description: Extención Billetera ClipClap para Opencart 2.0.x. Recibe pagos en atraves de la billetera ClipClap
- Version: 1.0.0
- Author: Jairo Ivan Rondon Mejia @digitalhydra
- License: GNU General Public License v3.0
- License URI: http://www.gnu.org/licenses/gpl-3.0.html
