<?php
/*
Plugin Name: ClipClap Module for Opencart 2.0.x
Plugin URI: http://codeiseverywhere.com/
Description: Billetera Clipclap for Opencart 2.0.x. !
Version: 1.0
Author: Code is everywhere - Jairo Ivan Rondon Mejia
Author URI: http://codeiseverywhere.com/
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/ 
class ControllerPaymentClipClap extends Controller {
	private $error = array(); 

	public function index() {
		$this->load->language('payment/clipclap');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('setting/setting');
//------------------------------------------------------------

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('clipclap', $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL'));
		}

		$arr = array( 
			"heading_title", 
			"text_payment", 
			"text_success", 
			"text_pay", 
			"text_card", 
			"entry_apikey",
			"entry_button_theme",  
			"entry_iva_type", 
			"entry_debug", 
			"entry_order_status_accepted",
			"entry_order_status_pending",
			"entry_order_status_declined",
			"entry_order_status_canceled",
			"entry_order_status_failed",
			"entry_order_status_expired", 
			"entry_status", 
			"entry_sort_order", 
			"error_permission", 
			"error_button_theme", 
			"error_iva_type",
			"error_apikey", 
			"entry_debug_on",
			"entry_debug_off",
		);

		foreach ($arr as $v) $data[$v] = $this->language->get($v);
		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['tab_status'] = $this->language->get('tab_status');
		$data['tab_general'] = $this->language->get('tab_general');



//------------------------------------------------------------
        $arr = array("warning", "merchant", "secretkey", "type");
        foreach ( $arr as $v ) $data['error_'.$v] = ( isset($this->error[$v]) ) ? $this->error[$v] : "";
//------------------------------------------------------------

		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => false
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_payment'),
			'href'      => $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('payment/clipclap', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);
				
		$data['action'] = $this->url->link('payment/clipclap', 'token=' . $this->session->data['token'], 'SSL');
		$data['cancel'] = $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL');

//------------------------------------------------------------
		$this->load->model('localisation/order_status');
		
		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
		$data['currencys'] = array(  'COP' );
		$data['languages'] = array('ES');
		$data['button_types'] = array(
            array('value' => 'blue',  'label' => 'Azul'),
            array('value' => 'black',  'label' => 'Negro'),
            array('value' => 'white',  'label' => 'Blanco')
        );
		$data['iva_types'] = array(
            array('value' => '16',  'label' => 'IVA Regular del 16%'),
            array('value' => '5',  'label' => 'IVA Reducido del 5%'),
            array('value' => '0',  'label' => 'IVA Excento del 0%'),
            array('value' => '0',  'label' => 'IVA Excluído del 0%'),
            array('value' => '8',  'label' => 'Consumo Regular 8%'),
            array('value' => '4',  'label' => 'Consumo Reducido 4%'),
            array('value' => '20',  'label' => 'IVA Ampliado 20%')
        );

		$data['testapikey'] = '6u39nqhq8ftd0hlvnjfs66eh8c';
		
		$arr = array( "clipclap_button_theme",
			"clipclap_apikey", 
			"clipclap_iva_type", 
			"clipclap_debug",
			"clipclap_status", 
			"clipclap_sort_order", 
			"clipclap_order_status_accepted",
			"clipclap_order_status_pending",
			"clipclap_order_status_declined",
			"clipclap_order_status_canceled",
			"clipclap_order_status_failed",
			"clipclap_order_status_expired"
		);

		foreach ( $arr as $v )
		{
			$data[$v] = ( isset($this->request->post[$v]) ) ? $this->request->post[$v] : $this->config->get($v);
		}
//------------------------------------------------------------

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
				
		$this->response->setOutput($this->load->view('payment/clipclap.tpl', $data));
	}

//------------------------------------------------------------
	private function validate() {
		if (!$this->user->hasPermission('modify', 'payment/clipclap')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		//echo $this->config->get('clipclap_test');
		if ($this->request->post['clipclap_test']=='Off') {
			if (!$this->request->post['clipclap_button_theme']) {
				$this->error['button_type'] = $this->language->get('error_button_theme');
			}

			if (!$this->request->post['clipclap_iva_type']) {
				$this->error['iva_type'] = $this->language->get('error_iva_type');
			}

			if (!$this->request->post['clipclap_apikey']) {
				$this->error['apikey'] = $this->language->get('error_apikey');
			}			
		}

		return !$this->error;
	}
}
?>