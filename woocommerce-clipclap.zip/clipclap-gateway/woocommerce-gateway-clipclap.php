<?php
/*
Plugin Name: WooCommerce - ClipClap Gateway
Plugin URI: http://thecodeisintheair.com/wordpress-plugins/woocommerce-clipclap-gateway-plugin/
Description: PayU Latinoamerica Payment Gateway for WooCommerce. Recibe pagos en internet en latinoamérica desde cualquier parte del mundo. ¡La forma más rápida, sencilla y segura para vender y recibir pagos por internet!
Version: 1.1.7
Author: Code is in the Air - Jairo Ivan Rondon Mejia
Author URI: http://www.thecodeisintheair.com/
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

add_action('plugins_loaded', 'woocommerce_clipclap_init', 0);
define('CLIPCLAP_ASSETS', plugin_dir_path( __FILE__ ) . '/assets');

function woocommerce_clipclap_init(){
	if(!class_exists('WC_Payment_Gateway')) return;

    if( isset($_GET['msg']) && !empty($_GET['msg']) ){
        add_action('the_content', 'showClipClapMessage');
    }
    function showClipClapMessage($content){
            return '<div class="'.htmlentities($_GET['type']).'">'.htmlentities(urldecode($_GET['msg'])).'</div>'.$content;
    }

	add_filter('woocommerce_payment_gateways', array('WC_clipclap','woocommerce_add_clipclap_gateway') );

    /**
	 * PayU Gateway Class
     *
     * @access public
     * @param
     * @return
     */
	class WC_clipclap extends WC_Payment_Gateway{

		public function __construct(){
			global $woocommerce;
			$this->load_plugin_textdomain();
	        //add_action('init', array($this, 'load_plugin_textdomain'));

			$this->id 					= 'clipclap';
			$this->icon_url 			= WP_PLUGIN_URL . "/" . plugin_basename(dirname(__FILE__)) . '/assets/img/'.$this->id.'-billetera.png';
			$this->method_title 		= __('ClipClap','clipclap-woocommerce');
			$this->method_description	= __("Paga fácil con tu celular, usando tarjetas de credito de cualquier banco en Colombia.",'clipclap-woocommerce');
			$this->has_fields 			= false;
			$this->supports           = array(
				'products',
			);
			$this->init_form_fields();
			$this->init_settings();
			$this->language 		= get_bloginfo('language');

			$this->testsecretkey	= 'Vj7tbQ1kDwrJZwu52vIY';
			$this->webkey 			= 'Vc7Jhi1v0DC9Tq0n6Ln5';
			$this->debug = "no";

			$this->title 			= $this->settings['title'];
			$this->description 		= $this->settings['description'];
			$this->secretkey 		= $this->settings['secretkey'];
			// $this->redirect_page_id = $this->settings['redirect_page_id'];
			
			$this->button_theme 	= $this->settings['button_theme'];
			$this->tipo_iva 		= $this->settings['tipo_iva'];
			$this->currency 		= ($this->is_valid_currency())?get_woocommerce_currency():'USD';

			$this->testmode 		= $this->settings['testmode'];

			/* mesagges */
			$this->msg_approved			= $this->settings['msg_approved'];
			$this->msg_declined			= $this->settings['msg_declined'];
			$this->msg_cancel 			= $this->settings['msg_cancel'];
			$this->msg_pending			= $this->settings['msg_pending'];


			add_filter( 'woocommerce_currencies', 'clipclap_add_all_currency' );
			add_filter( 'woocommerce_currency_symbol', 'clipclap_add_all_symbol', 10, 2);

			$this->msg['message'] 	= "";
			$this->msg['class'] 	= "";
			// Logs
			// if ( 'yes' == $this->debug ){
				if(version_compare( WOOCOMMERCE_VERSION, '2.1', '>=')){
					$this->log = new WC_Logger();
				}else{
					$this->log = $woocommerce->logger();
				}
			// }


			add_action('clipclap_init', array( $this, 'clipclap_successful_request'));
			add_action( 'woocommerce_receipt_clipclap', array( $this, 'receipt_page' ) );
			//update for woocommerce >2.0
			add_action( 'woocommerce_api_' . strtolower( get_class( $this ) ), array( $this, 'check_clipclap_response' ) );

			if ( version_compare( WOOCOMMERCE_VERSION, '2.0.0', '>=' ) ) {
				/* 2.0.0 */
				add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( &$this, 'process_admin_options' ) );
			} else {
				/* 1.6.6 */
				add_action( 'woocommerce_update_options_payment_gateways', array( &$this, 'process_admin_options' ) );
			}

		}

	    public function load_plugin_textdomain()
	    {
			load_plugin_textdomain( 'clipclap-woocommerce', false, dirname( plugin_basename( __FILE__ ) ) . "/languages" );
	    }

		/**
		 * get_icon function.
		 *
		 * @return string
		 */
		public function get_icon() {
			$icon_html = '';

			$icon_html .= '<img src="' . $this->icon_url . '" width="120" alt="' . esc_attr__( 'ClipClap Billetera', 'woocommerce' ) . '" />';
			

			$icon_html .= sprintf( '<a href="%1$s" class="clipclap_icon" style="float:right;"  onclick="javascript:window.open(\'%1$s\',\'WIClipclap\',\'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, width=1060, height=700\'); return false;" title="' . esc_attr__( 'Que es ClipClap?', 'woocommerce' ) . '">' . esc_attr__( 'Que es ClipClap', 'woocommerce' ) . '</a>', esc_url( 'https://www.clipclap.co/billetera/' ) ) ;

			return apply_filters( 'woocommerce_gateway_icon', $icon_html, $this->id );
		}

		/**
		* Add the Gateway to WooCommerce
		**/
		public static function woocommerce_add_clipclap_gateway($methods) {
			$methods[] = 'WC_clipclap';
			return $methods;
		}

    	/**
		 * Check if Gateway can be display
	     *
	     * @access public
	     * @return void
	     */
	    function is_available() {
			global $woocommerce;

			if ( $this->enabled=="yes" ) :

				if ( !$this->is_valid_currency()) return false;

				if ( $woocommerce->version < '1.5.8' ) return false;

				if (!$this->secretkey ) return false;

				return true;
			endif;

			return false;
		}

    	/**
		 * Settings Options
	     *
	     * @access public
	     * @return void
	     */
		function init_form_fields(){
			$this->form_fields = array(
				'enabled' => array(
					'title' 		=> __('Enable/Disable', 'clipclap-woocommerce'),
					'type' 			=> 'checkbox',
					'label' 		=> __('Activar pagos por ClipClap.', 'clipclap-woocommerce'),
					'default' 		=> 'no',
					'description' 	=> __('Show in the Payment List as a payment option', 'clipclap-woocommerce')
				),
      			'title' => array(
					'title' 		=> __('Title:', 'clipclap-woocommerce'),
					'type'			=> 'text',
					'default' 		=> __('Pagar con Billetera ClipClap', 'clipclap-woocommerce'),
					'description' 	=> __('This controls the title which the user sees during checkout.', 'clipclap-woocommerce'),
					'desc_tip' 		=> true
				),
      			'description' => array(
					'title' 		=> __('Descripcion:', 'clipclap-woocommerce'),
					'type' 			=> 'textarea',
					'default' 		=> __('Paga fácil con tu celular, usando tarjetas de credito de cualquier banco en Colombia.','clipclap-woocommerce'),
					'description' 	=> __('This controls the description which the user sees during checkout.', 'clipclap-woocommerce'),
					'desc_tip' 		=> true
				),
      			'secretkey' => array(
					'title' 		=> __('Secret Key', 'clipclap-woocommerce'),
					'type' 			=> 'text',
					'description' 	=>  __('Lo encuentra en su panel de configuracion de ClipClap', 'clipclap-woocommerce'),
					'desc_tip' 		=> true
                ),
      			'button_theme' => array(
					'title' 		=> __('Tema del boton', 'clipclap-woocommerce'),
					'type' 			=> 'select',
					'options' 		=> array( 'blue'=>'Azul', 'black'=>'Negro', 'white'=>'Blanco'),
					'description' 	=> __('El color que tendra el boton', 'clipclap-woocommerce'),
					'default' 		=> 'blue',
					'desc_tip' 		=> true
                ),
      			'return_url' => array(
					'title' 		=> __('Url de respuesta:', 'clipclap-woocommerce'),
					'type'			=> 'text',
					'default' 		=> get_site_url().'/?wc-api='.get_class( $this ),
					'description' 	=> __('use esta url en su configuracion de clipclap como pagina de retorno.', 'clipclap-woocommerce'),
					'desc_tip' 		=> true,
					'custom_attributes'=>array('readonly'=>true)
				),
      			'tipo_iva' => array(
					'title' 		=> __('Tipo de iva', 'clipclap-woocommerce'),
					'type' 			=> 'select',
					'options' 		=> array(1 => 'IVA Regular del 16%', 2 => 'IVA Reducido del 5%', 3 => 'IVA Excento del 0%', 4 => 'IVA Excluído del 0%', 5 => 'Consumo Regular 8%', 6 => 'Consumo Reducido 4%', 7 => 'IVA Ampliado 20%'),
					'description' 	=> __('El el tipo de iva que manejan las transacciones', 'clipclap-woocommerce'),
					'desc_tip' 		=> true
                ),
      			/*'redirect_page_id' => array(
					'title' 		=> __('Pagina de redireccion', 'clipclap-woocommerce'),
					'type' 			=> 'select',
					'options' 		=> $this->get_pages(__('Select Page', 'clipclap-woocommerce')),
					'description' 	=> __('URL of success page', 'clipclap-woocommerce'),
					'desc_tip' 		=> true
                ),*/
      			'testmode' => array(
					'title' 		=> __('Activar modo de pruebas', 'clipclap-woocommerce'),
					'type' 			=> 'checkbox',
					'label' 		=> __('Activar transacciones de prueba.', 'clipclap-woocommerce'),
					'default' 		=> 'no',
					'description' 	=> __('Tick to run TEST Transaction on the PayU Latam platform', 'clipclap-woocommerce'),
					'desc_tip' 		=> true
                ),
      			'msg_approved' => array(
					'title' 		=> __('Message for approved transaction', 'clipclap-woocommerce'),
					'type' 			=> 'text',
					'default' 		=> __('Payment Approved', 'clipclap-woocommerce'),
					'description' 	=> __('Message for approved transaction', 'clipclap-woocommerce'),
					'desc_tip' 		=> true
                ),
      			'msg_pending' => array(
					'title' 		=> __('Message for pending transaction', 'clipclap-woocommerce'),
					'type' 			=> 'text',
					'default' 		=> __('Payment pending', 'clipclap-woocommerce'),
					'description' 	=> __('Message for pending transaction', 'clipclap-woocommerce'),
					'desc_tip' 		=> true
                ),
      			'msg_cancel' => array(
					'title' 		=> __('Message for cancel transaction', 'clipclap-woocommerce'),
					'type' 			=> 'text',
					'default' 		=> __('Transaction Canceled.', 'clipclap-woocommerce'),
					'description' 	=> __('Message for cancel transaction', 'clipclap-woocommerce'),
					'desc_tip' 		=> true
                ),
      			'msg_declined' => array(
					'title' 		=> __('Message for declined transaction', 'clipclap-woocommerce'),
					'type' 			=> 'text',
					'default' 		=> __('Payment rejected by ClipClap.', 'clipclap-woocommerce'),
					'description' 	=> __('Message for declined transaction ', 'clipclap-woocommerce'),
					'desc_tip' 		=> true
                ),
			);
		}

        /**
         * Generate Admin Panel Options
	     *
	     * @access public
	     * @return string
         **/
		public function admin_options(){
			echo '<img src="'.$this->icon_url.'" alt="ClipClap" width="80"><h3>'.__('ClipClap', 'clipclap-woocommerce').'</h3>';
			echo '<p>'.__('Paga fácil con tu celular, usando tarjetas de credito de cualquier banco en Colombia.', 'clipclap-woocommerce').'</p>';
			echo '<table class="form-table">';
			// Generate the HTML For the settings form.
			$this->generate_settings_html();
			echo '</table>';
		}

		/**
	     * Generate Admin Panel Options
	     *
	     * @access public
	     * @return string
	     **/
		public function payment_fields() {
			global $woocommerce;
			
			if ( $this->description )
				echo '<p>' . $this->description .'</p>';
			
		}

		/**
		 * Generate the ClipClap Form for checkout
	     *
	     * @access public
	     * @param mixed $order
	     * @return string
		**/
		function receipt_page($order){
			echo '<p>'.__('Revisa tu pedido y presiona el siguiente botón para pagar', 'clipclap-woocommerce').'</p>';
			echo $this->generate_clipclap_form($order);
		}

		/**
		 * Generate PayU POST arguments
	     *
	     * @access public
	     * @param mixed $order_id
	     * @return string
		**/
		function get_clipclap_args($order){
			global $woocommerce;
			// $order = new WC_Order( $order_id );
			$txnid = $order->order_key;
			
			//For wooCoomerce 2.0
			// $redirect_url = add_query_arg( 'wc-api', get_class( $this ), $redirect_url );
			// $redirect_url = add_query_arg( 'order_id', $order_id, $redirect_url );
			// $redirect_url = add_query_arg( '', $this->endpoint, $redirect_url );

			$order_description = "Order $order->id";

			$clipclap_args = array(
				'paymentRef' 		=> $txnid,
				'netValue' 			=> $order->order_total,
				'description'		=> $order_description,
				'taxId' 			=> $this->tipo_iva,
					'tipValue' 			=> '0'
			);
			return $clipclap_args;
		}

		/**
		 * Generate the ClipClap button link
	     *
	     * @access public
	     * @param mixed $order_id
	     * @return string
	    */
	    function generate_clipclap_form( $order_id ) {
			global $woocommerce;

			$order = new WC_Order( $order_id );
			
			$clipclap_args = $this->get_clipclap_args( $order );
			$tax_rate = $this->get_tax_rate($clipclap_args["netValue"],$this->tipo_iva);
			
			$api_url = get_site_url().'/?wc-api='.strtolower( get_class( $this ) );

			$redirect_url = $order->get_checkout_order_received_url();
			?>
				<button type="button" id="botonClipClap"></button>
				<script type="text/javascript">
				
				var _$clipclap = _$clipclap || {};
					_$clipclap._setKey = '<?php echo $this->secretkey; ?>';
		          	_$clipclap._themeButton = '<?php echo $this->button_theme; ?>';
		          	_$clipclap.transactionState = function(status, codRespuesta, paymentRef, token, numAprobacion, fechaTransaccion){

				            jQuery("body").block({
								message: "Estamos procesando el pedido.",
								baseZ: 99999,
								overlayCSS:{ background: "#fff", opacity: 0.6 },
								css: { padding:"20px", zindex:"9999999", textAlign:"center",color:"#555",border: "3px solid #aaa",backgroundColor:"#fff",cursor:"wait",lineHeight:"24px",
							    }
							});
				            var transactionData = {
				            	'estado' : status,
				            	'codRespuesta' : codRespuesta,
				            	'paymentRef' : paymentRef,
				            	'token' : token,
				            	'numAprobacion' : numAprobacion,
				            	'fechaTransaccion' : fechaTransaccion
				            }
				            
							jQuery.post( '<?php echo $api_url; ?>', transactionData )
							.done(function( data ) {
							    window.location = '<?php echo $redirect_url; ?>';
							});
			        }
			        <?php if($this->testmode=='yes'): ?> 
			        	_$clipclap._debugButton = true; 
			        <?php endif; ?>

		          	_$clipclap._Buttons = {
			            "#botonClipClap":{
			            	'paymentRef': '<?php echo $clipclap_args["paymentRef"]; ?>',
			              	'netValue': '<?php echo $clipclap_args["netValue"]; ?>',
			              	'taxValue': '<?php echo $tax_rate; ?>',
			              	'tipValue': '',
			              	'description': '<?php echo $clipclap_args["description"]; ?>'
			            },
		            };
		      (function() {
		        var cc = document.createElement('script'); cc.type = 'text/javascript'; cc.async = true;
		        cc.src = 'https://clipclap.co/paybutton/js/paybutton.min.js';
		        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(cc, s);
		      })();
		    </script>
			<?php

		}

		/**
	     * Process the payment and return the result
	     *
	     * @access public
	     * @param int $order_id
	     * @return array
	     */
		function process_payment( $order_id ) {
			$order = new WC_Order( $order_id );
			
				if (version_compare( WOOCOMMERCE_VERSION, '2.1', '>=')) {
					return array(
						'result' 	=> 'success',
						'redirect'	=> add_query_arg('order-pay', $order->id, add_query_arg('key', $order->order_key, get_permalink(woocommerce_get_page_id('pay' ))))
					);
				} else {
					return array(
						'result' 	=> 'success',
						'redirect'	=> add_query_arg('order', $order->id, add_query_arg('key', $order->order_key, get_permalink(woocommerce_get_page_id('pay' ))))
					);
				}

		}

		/**
		 * Check for valid clipclap server callback
		 *
		 * @access public
		 * @return void
		**/
		function check_clipclap_response(){
			@ob_clean();
			
	    	if ( ! empty( file_get_contents('php://input') ) || !empty($_REQUEST)) {
	    		header( 'HTTP/1.1 200 OK' );
	    		$responseBody = ($_REQUEST)?$_REQUEST:json_decode( file_get_contents('php://input'), TRUE );
	        	do_action( "clipclap_init", $responseBody );
			} else {
				wp_die( __("ClipClap Request Failure", 'clipclap-woocommerce') );
	   		}
		}

		/**
		 * Process Payu Response and update the order information
		 *
		 * @access public
		 * @param array $posted
		 * @return void
		 */
		function clipclap_successful_request( $posted ) {
			global $woocommerce;

		    $this->log->add( 'clipclap', 'Callback Clipclap order '.print_r($posted,true) );
		    //confirmation process
		    if ( ! empty( $posted['paymentRef'] ) && ! empty( $posted['estado'] ) ) {
			    $order = $this->get_clipclap_order( $posted['paymentRef'] );

		        $this->log->add( 'clipclap', 'Found order #' . $order->id );

		         if(!empty($posted['codRespuesta'])) {

			        $this->log->add( 'clipclap', 'Payment status: ' . $posted['codRespuesta'] );

		        	// We are here so lets check status and do actions
			        switch ( $posted['codRespuesta']) {
			            case '3001' :
			            	// Check order not already completed
			            	if ( $order->status == 'completed' ) {
			            		 	$this->log->add( 'clipclap', __('Abortando, Orden #' . $order->id . ' ya fue completada.', 'clipclap-woocommerce') );
			            		 exit;
			            	}
							 // Store PP Details
			                if ( ! empty( $posted['numAprobacion'] ) )
			                	update_post_meta( $order->id, __('ClipClap numAprobacion', 'clipclap-woocommerce'), $posted['numAprobacion'] );
			                if ( ! empty( $posted['fechaTransaccion'] ) )
			                	update_post_meta( $order->id, __('fechaTransaccion', 'clipclap-woocommerce'), $posted['fechaTransaccion'] );
			                if ( ! empty( $posted['codRespuesta'] ) )
			                	update_post_meta( $order->id, __('codRespuesta', 'clipclap-woocommerce'), $posted['codRespuesta'] );
			                if ( ! empty( $posted['token'] ) )
			                	update_post_meta( $order->id, __('token', 'clipclap-woocommerce'), $posted['token'] );
			                
			               	update_post_meta( $order->id, __('Posted Data', 'clipclap-woocommerce'), json_encode($posted));
			                
		                	$order->add_order_note( __( 'Pago aprovado por ClipClap', 'clipclap-woocommerce') );
							$this->msg['message'] =  $this->msg_approved;
							$this->msg['class'] = 'woocommerce-message';
		                	$order->payment_complete();
		                 
		                	$this->log->add( 'clipclap', __('Payment complete. Orden:' .$order->id, 'clipclap-woocommerce'));

			            break;
			            case '1002' :
			                // Order failed
							 // Store  Details
			                if ( ! empty( $posted['paymentRef'] ) )
			                	update_post_meta( $order->id, __('ClipClap paymentRef', 'clipclap-woocommerce'), $posted['paymentRef'] );
			                if ( ! empty( $posted['estado'] ) )
			                	update_post_meta( $order->id, __('estado', 'clipclap-woocommerce'), $posted['estado'] );
			                if ( ! empty( $posted['codRespuesta'] ) )
			                	update_post_meta( $order->id, __('codRespuesta', 'clipclap-woocommerce'), $posted['codRespuesta'] );
			                if ( ! empty( $posted['token'] ) )
			                	update_post_meta( $order->id, __('token', 'clipclap-woocommerce'), $posted['token'] );
			                
			               	update_post_meta( $order->id, __('Posted Data', 'clipclap-woocommerce'), json_encode($posted));
			                
			                $order->update_status( 'failed', sprintf( __( 'Pago rechazado por ClipClap. Error type: %s', 'clipclap-woocommerce'), $posted['codRespuesta'] ) );
								$this->msg['message'] = $this->msg_declined ;
								$this->msg['class'] = 'woocommerce-error';
			            break;
			            case '1000' :
			                // Order failed
			                
							 // Store Details
			                if ( ! empty( $posted['paymentRef'] ) )
			                	update_post_meta( $order->id, __('ClipClap paymentRef', 'clipclap-woocommerce'), $posted['paymentRef'] );
			                if ( ! empty( $posted['estado'] ) )
			                	update_post_meta( $order->id, __('estado', 'clipclap-woocommerce'), $posted['estado'] );
			                if ( ! empty( $posted['codRespuesta'] ) )
			                	update_post_meta( $order->id, __('codRespuesta', 'clipclap-woocommerce'), $posted['codRespuesta'] );
			                if ( ! empty( $posted['token'] ) )
			                	update_post_meta( $order->id, __('token', 'clipclap-woocommerce'), $posted['token'] );
			                
			               	update_post_meta( $order->id, __('Posted Data', 'clipclap-woocommerce'), json_encode($posted));
			                
			                $order->update_status( 'failed', sprintf( __( 'Pago rechazado por el usuario - ClipClap. Error type: %s', 'clipclap-woocommerce'), $posted['codRespuesta'] ) );
								$this->msg['message'] = $this->msg_declined ;
								$this->msg['class'] = 'woocommerce-error';
			            break;
			            default :
			                $order->update_status( 'on-hold', sprintf( __( 'Pago pendiente: %s', 'clipclap-woocommerce'), $posted['lapResponseCode'] ) );
							$this->msg['message'] = $this->msg_pending;
							$this->msg['class'] = 'woocommerce-info';
			            break;
			        }
		        }

				$redirect_url = get_site_url().'/?order-received='.$order_id.'&key='.$order->order_key;
                //For wooCoomerce 2.0
                $redirect_url = add_query_arg( array('msg'=> urlencode($this->msg['message']), 'type'=>$this->msg['class']), $redirect_url );

                wp_redirect( $redirect_url );
                // exit;
		    }else{
		    	//For wooCoomerce 2.0
                
				$redirect_url = get_site_url().'/?order-received='.$order_id.'&key='.$order->order_key;
                //For wooCoomerce 2.0
                $redirect_url = add_query_arg( array('msg'=> urlencode($this->msg['message']), 'type'=>$this->msg['class']), $redirect_url );

                wp_redirect( $redirect_url );

		    }
				
		}

		/**
		 *  Get order information
		 *
		 * @access public
		 * @param mixed $posted
		 * @return void
		 */
		function get_clipclap_order( $order_key ) {
			
			$order_id 	= woocommerce_get_order_id_by_order_key( $order_key );
			$order 		= new WC_Order( $order_id );
			
			// Validate key
			if ( $order->order_key !== $order_key ) {
	        	if ( $this->debug=='yes' )
	        		$this->log->add( 'clipclap', __('Error: Order Key does not match invoice.', 'clipclap-woocommerce') );
	        	exit;
	        }

	        return $order;
		}

		/**
		 * Check the tax rates active in woocommerce.
		 *
		 * @access public
		 * @return bool
		 */
		function get_tax_rate($value,$tipo) {
			$taxes = array(1 => 16, 2 => 5, 3 => 0, 4 => 0, 5 => 8, 6 => 4, 7 => 20);
			
			$tax_rate = ($value * $taxes[$tipo])/100;

			return $tax_rate;
		}

		/**
		 * Check if current currency is valid for ClipClap
		 *
		 * @access public
		 * @return bool
		 */
		function is_valid_currency() {
			if ( ! in_array( get_woocommerce_currency(), apply_filters( 'woocommerce_clipclap_supported_currencies', array( 'COP', 'USD' ) ) ) ) return false;

			return true;
		}

		/**
		 * Get pages for return page setting
		 *
		 * @access public
		 * @return bool
		 */
		function get_pages($title = false, $indent = true) {
			$wp_pages = get_pages('sort_column=menu_order');
			$page_list = array();
			if ($title) $page_list[] = $title;
			foreach ($wp_pages as $page) {
				$prefix = '';
				// show indented child pages?
				if ($indent) {
                	$has_parent = $page->post_parent;
                	while($has_parent) {
                    	$prefix .=  ' - ';
                    	$next_page = get_page($has_parent);
                    	$has_parent = $next_page->post_parent;
                	}
            	}
            	// add to page list array array
            	$page_list[$page->ID] = $prefix . $page->post_title;
        	}
        	return $page_list;
    		}
		}


		/**
		 * Add all currencys supported by PayU Latem so it can be display
		 * in the woocommerce settings
		 *
		 * @access public
		 * @return bool
		 */
		function clipclap_add_all_currency( $currencies ) {
			// $currencies['ARS'] = __( 'Argentine Peso', 'clipclap-woocommerce');
			// $currencies['BRL'] = __( 'Brasilian Real', 'clipclap-woocommerce');
			$currencies['COP'] = __( 'Colombian Peso', 'clipclap-woocommerce');
			// $currencies['MXN'] = __( 'Mexican Peso', 'clipclap-woocommerce');
			// $currencies['CLP'] = __( 'Chile Peso', 'clipclap-woocommerce');
			// $currencies['PEN'] = __( 'Perubian New Sol', 'clipclap-woocommerce');
			return $currencies;
		}

		/**
		 * Add simbols for all currencys in ClipClap so it can be display
		 * in the woocommerce settings
		 *
		 * @access public
		 * @return bool
		 */
		function clipclap_add_all_symbol( $currency_symbol, $currency ) {
			switch( $currency ) {
			// case 'ARS': $currency_symbol = '$'; break;
			// case 'CLP': $currency_symbol = '$'; break;
			// case 'BRL': $currency_symbol = 'R$'; break;
			case 'COP': $currency_symbol = '$'; break;
			// case 'MXN': $currency_symbol = '$'; break;
			// case 'PEN': $currency_symbol = 'S/.'; break;
			}
			return $currency_symbol;
		}


		//add_filter('woocommerce_payment_gateways', 'woocommerce_add_clipclap_gateway' );

	}

	/**
	 * Filter simbol for currency currently active so it can be display
	 * in the front end
     *
     * @access public
     * @param (string) $currency_symbol, (string) $currency
     * @return (string) filtered currency simbol
     */
	function public_clipclap_currency_symbols( $currency_symbol, $currency ) {
		switch( $currency ) {
		// case 'ARS': $currency_symbol = '$'; break;
		// case 'CLP': $currency_symbol = '$'; break;
		// case 'BRL': $currency_symbol = 'R$'; break;
		case 'COP': $currency_symbol = '$'; break;
		// case 'MXN': $currency_symbol = '$'; break;
		// case 'PEN': $currency_symbol = 'S/.'; break;
		}
		return $currency_symbol;
	}
	add_filter( 'woocommerce_currency_symbol', 'public_clipclap_currency_symbols', 1, 2);


	add_action('wp_head','clipclap_ajaxurl');
	function clipclap_ajaxurl() { ?>
	    <script type="text/javascript">
	    var clipclap_ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
	    </script>
	<?php
	}
