=== Plugin Name ===
Contributors: deusnoname
Donate link: http://clipclap.co
Tags: WooCommerce, Payment Gateway, Clipclap, Pagos en linea Colombia, Pagos en linea Latinoamerica
Requires at least: 3.7
Tested up to: 4.4
Stable tag: 1.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

ClipClap Payment Gateway for WooCommerce. Recibe pagos en internet en latinoaméica desde cualquier parte del mundo.

== Description ==

WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.

ClipClap - la plataforma de procesamiento de pagos en linea de América Latina, Crea tu Cuenta [aqui](https://clipclap.co/ "ClipClap").

Both are now one of the best choices to start an eCommerece site in latinoamerica, fast and easy.
*   "WooCommerce" is an open source application
*   "ClipClap" is offering payment collection with no setup cost.

Note:
To test the payment platform you must configure your account in test mode:

== Installation ==

1. Ensure you have latest version of WooCommerce plugin installed (WooCommerce 2.0+)
2. Unzip and upload contents of the plugin to your `/wp-content/plugins/` directory
3. Activate the plugin through the 'Plugins' menu in WordPress

Please see the screenshots on information about how to get your account info from Payu Latam.

== Configuration ==

1. Visit the WooCommerce settings page, and click on the Payment Gateways tab.
2. Click on *ClipClap* to edit the settings. If you do not see *ClipClap* in the list at the top of the screen make sure you have activated the plugin in the WordPress Plugin Manager.
3. Enable the Payment Method, name it as you want (this will show up on the payment page your customer sees), add in your Secret Key. Click Save.

== Screenshots ==

1. WooCommerce > Payment Gateway > ClipClap - setting page

== Frequently Asked Questions ==

= What is the cost for transaction for ClipClap? =

It may vary on each country, check clipclap.com to learn more.

= Issues =

== Changelog ==

= 1.0 =
* First Public Release.


== Upgrade Notice ==
